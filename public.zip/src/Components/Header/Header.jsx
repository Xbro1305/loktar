import React from "react";
import { useNavigate } from "react-router-dom";
import "./Header.css";

export const Header = () => {
  const navigate = useNavigate();
  return (
    <header>
      <section className="logo">
        <img src="https://loktar-imgs.netlify.app/logo.svg" alt="" />
        <h1>ЛОКТАР</h1>
      </section>
      <section className="navigation">
        <img
          onClick={() => navigate("/cart")}
          src="https://loktar-imgs.netlify.app/cart.svg"
          alt=""
        />
        <img src="https://loktar-imgs.netlify.app/saved.png" alt="" />
        <img src="https://loktar-imgs.netlify.app/menu.png" alt="" />
      </section>
    </header>
  );
};
